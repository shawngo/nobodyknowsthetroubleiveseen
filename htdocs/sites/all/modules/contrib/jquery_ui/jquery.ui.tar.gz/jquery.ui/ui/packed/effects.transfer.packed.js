/*
 * jQuery UI Effects Transfer 1.6
 *
 * Copyright (c) 2008 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Transfer
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(5(A){A.8.f=5(B){x d.w(5(){4 E=A(d);4 G=A.8.z(E,B.3.H||"v");4 F=A(B.3.I);4 C=E.g();4 D=A(\'<j t="q-8-f"></j>\').s(J.L);p(B.3.9){D.i(B.3.9)}D.i(B.3.9);D.1({7:C.7,6:C.6,k:E.l()-2(D.1("e"))-2(D.1("a")),b:E.c()-2(D.1("h"))-2(D.1("m")),R:"O"});C=F.g();n={7:C.7,6:C.6,k:F.l()-2(D.1("e"))-2(D.1("a")),b:F.c()-2(D.1("h"))-2(D.1("m"))};D.Q(n,B.K,B.3.P,5(){D.N();p(B.o){B.o.r(E[0],u)}E.y()})})}})(M)',54,54,'|css|parseInt|options|var|function|left|top|effects|className|borderBottomWidth|width|outerWidth|this|borderTopWidth|transfer|offset|borderLeftWidth|addClass|div|height|outerHeight|borderRightWidth|animation|callback|if|ui|apply|appendTo|class|arguments|effect|queue|return|dequeue|setMode||||||||mode|to|document|duration|body|jQuery|remove|absolute|easing|animate|position'.split('|'),0,{}))
